package com.example.demoappaccountkit;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.huawei.hmf.tasks.Task;
import com.huawei.hms.common.ApiException;
import com.huawei.hms.support.account.AccountAuthManager;
import com.huawei.hms.support.account.request.AccountAuthParams;
import com.huawei.hms.support.account.request.AccountAuthParamsHelper;
import com.huawei.hms.support.account.result.AuthAccount;
import com.huawei.hms.support.account.service.AccountAuthService;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "DemoAppAccountKit";
    Button btnSignInID, btnAutho;
    AccountAuthParams authParams;
    AccountAuthService authService;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnSignInID = findViewById(R.id.btnSignInID);
        btnAutho = findViewById(R.id.btnAutho);
        btnAutho.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signinAutho();
            }
        });
        btnSignInID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signInId();
            }
        });
    }

    private void signinAutho(){
        authParams = new AccountAuthParamsHelper(AccountAuthParams.DEFAULT_AUTH_REQUEST_PARAM)
                .setAuthorizationCode().createParams();
        authService = AccountAuthManager.getService(MainActivity.this, authParams);
        signinAuthoResult.launch(authService.getSignInIntent());
    }

    ActivityResultLauncher<Intent> signinAuthoResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
        @Override
        public void onActivityResult(ActivityResult result) {
        Intent data = result.getData();
        Task<AuthAccount> authAccountTask = AccountAuthManager.parseAuthResultFromIntent(data);
        if(authAccountTask.isSuccessful()){
            //lay thong tin tai khoan
            AuthAccount authAccount = authAccountTask.getResult();
            //hien thi thong tin tai khoan
            Log.i(TAG, "Authorziration Code: " + authAccount.getAuthorizationCode());

        } else {
            Log.i(TAG,"Sign in failed: " + ((ApiException)authAccountTask.getException()).getStatusCode());
            }
        }
    });

    ActivityResultLauncher<Intent> signInIDResult = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
        @Override
        public void onActivityResult(ActivityResult result) {
            //xu ly ket qua tra ve khi dang nhap
            Intent data = result.getData();
            //id-token signIn
            Task<AuthAccount> authAccountTask = AccountAuthManager.parseAuthResultFromIntent(data);
            if(authAccountTask.isSuccessful()){
                AuthAccount authAccount = authAccountTask.getResult();
                Log.i(TAG, authAccount.getDisplayName()+ "signIn success");
                Log.i(TAG, "idToken + {" + authAccount.getIdToken()+"}");
            } else {
                Log.i(TAG, "sign in failed: " + ((ApiException)authAccountTask.getException()).getStatusCode());
            }
        }
    });

    private void signInId(){
        authParams = new AccountAuthParamsHelper(AccountAuthParams.DEFAULT_AUTH_REQUEST_PARAM).setIdToken().setAccessToken().createParams();
        authService= AccountAuthManager.getService(MainActivity.this,authParams);
        signInIDResult.launch(authService.getSignInIntent());
    }




}

